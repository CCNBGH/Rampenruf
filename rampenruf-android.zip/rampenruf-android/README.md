# Rampenruf Android-App

Dies ist die installierbare Android-Version der Rampenruf-Web-App.

## Wichtig

Die APK kann aus diesem Projekt mit Android Studio kostenlos gebaut werden. In dieser Umgebung ist kein Android SDK verfügbar, deshalb liegt hier das vollständige Android-Projekt bei, nicht die bereits kompilierte APK.

## Voraussetzungen

- Android Studio
- Ein Android-Smartphone oder Emulator
- Supabase Free-Projekt für die Datenbank

## Einrichtung

1. Projektordner `rampenruf-android` in Android Studio öffnen.
2. Datei öffnen:
   `app/src/main/assets/config.js`
3. Supabase-Werte eintragen:

```js
window.RAMPENRUF_CONFIG = {
  SUPABASE_URL: "https://DEIN-PROJEKT.supabase.co",
  SUPABASE_ANON_KEY: "DEIN-ANON-KEY",
  ADMIN_PIN: "1234",
  SITE_URL: "file:///android_asset/index.html"
};
```

4. In Supabase das SQL ausführen:
   `app/src/main/assets/database.sql`
5. Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. APK auf das Smartphone kopieren und installieren.

## Installation auf dem Smartphone

1. APK-Datei auf das Android-Smartphone kopieren.
2. Datei öffnen.
3. Falls Android blockiert: „Installation aus unbekannten Quellen erlauben“ aktivieren.
4. App installieren.
5. App „Rampenruf“ starten.

## Funktionen

- Fahrer-Anmeldung
- Admin-Bereich
- Warteliste
- Rampenzuweisung
- SMS-App mit fertigem Nachrichtentext öffnen
- Telefonlink direkt anklickbar
- Bedienung auf Smartphone und Tablet

## Hinweis zu SMS

Die App öffnet kostenlos die SMS-App mit fertigem Text. Automatischer SMS-Versand ohne Klick ist nicht dauerhaft kostenlos und benötigt einen bezahlten SMS-Anbieter.
