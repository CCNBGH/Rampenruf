const cfg = window.RAMPENRUF_CONFIG;
const db = supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
const form = document.getElementById('driverForm');
const result = document.getElementById('result');

function show(msg, ok=true){
  result.className = ok ? 'result ok' : 'result err';
  result.textContent = msg;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  const row = {
    driver_name: data.driver_name.trim(),
    phone: data.phone.trim(),
    plate: data.plate.trim().toUpperCase(),
    tour: data.tour.trim(),
    company: data.company.trim(),
    status: 'wartet'
  };
  const { error } = await db.from('drivers').insert(row);
  if (error) return show('Fehler bei der Anmeldung: ' + error.message, false);
  form.reset();
  show('Anmeldung erfolgreich. Bitte warten Sie auf die Rampenbenachrichtigung.');
});
