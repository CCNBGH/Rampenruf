// Datei zu config.js kopieren und Werte eintragen.
window.RAMPENRUF_CONFIG = {
  SUPABASE_URL: "https://DEIN-PROJEKT.supabase.co",
  SUPABASE_ANON_KEY: "DEIN_ANON_KEY",
  ADMIN_PIN: "1234",
  SITE_URL: "https://dein-name.github.io/rampenruf-app/"
};
