create table if not exists public.drivers (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  driver_name text not null,
  phone text not null,
  plate text not null,
  tour text,
  company text,
  status text not null default 'wartet',
  ramp text,
  called_at timestamptz,
  finished_at timestamptz
);

alter table public.drivers enable row level security;

-- Für MVP: öffentliches Registrieren und Lesen/Aktualisieren über anon key.
-- Für echten Betrieb später absichern, z. B. mit Login/Rollen.
drop policy if exists "public_insert_drivers" on public.drivers;
create policy "public_insert_drivers" on public.drivers for insert with check (true);

drop policy if exists "public_select_drivers" on public.drivers;
create policy "public_select_drivers" on public.drivers for select using (true);

drop policy if exists "public_update_drivers" on public.drivers;
create policy "public_update_drivers" on public.drivers for update using (true) with check (true);

alter publication supabase_realtime add table public.drivers;
