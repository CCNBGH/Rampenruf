const cfg = window.RAMPENRUF_CONFIG;
const db = supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
const loginBox = document.getElementById('loginBox');
const adminBox = document.getElementById('adminBox');
const rows = document.getElementById('rows');
const statusEl = document.getElementById('status');
const driverUrl = document.getElementById('driverUrl');
let channel;

function esc(s){return String(s ?? '').replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function smsHref(phone, text){ return `sms:${encodeURIComponent(phone)}?&body=${encodeURIComponent(text)}`; }

async function load(){
  statusEl.textContent = 'Lade...';
  const { data, error } = await db.from('drivers').select('*').order('created_at', { ascending: true }).limit(200);
  if(error){ statusEl.textContent = error.message; return; }
  rows.innerHTML = data.map(d => {
    const msg = `Bitte fahren Sie an Rampe ${d.ramp || '__'} zur Entladung. Kennzeichen: ${d.plate}.`;
    return `<tr>
      <td data-label="Zeit">${new Date(d.created_at).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})}</td>
      <td data-label="Fahrer">${esc(d.driver_name)}<br><small>${esc(d.company)}</small></td>
      <td data-label="Telefon"><a href="tel:${esc(d.phone)}">${esc(d.phone)}</a></td>
      <td data-label="Kennzeichen">${esc(d.plate)}</td>
      <td data-label="Tour">${esc(d.tour)}</td>
      <td data-label="Status"><span class="badge ${esc(d.status)}">${esc(d.status)}</span></td>
      <td data-label="Rampe"><input class="ramp" data-id="${d.id}" value="${esc(d.ramp)}" placeholder="60" inputmode="numeric"></td>
      <td data-label="Aktion"><div class="actions">
        <button data-call="${d.id}">Zuweisen</button>
        <a class="button" href="${smsHref(d.phone, msg)}">SMS öffnen</a>
        <button class="secondary" data-done="${d.id}">Erledigt</button>
      </div></td>
    </tr>`;
  }).join('');
  statusEl.textContent = `${data.length} Einträge`;
}

async function updateDriver(id, fields){
  const { error } = await db.from('drivers').update(fields).eq('id', id);
  if(error) alert(error.message);
  await load();
}

document.getElementById('loginBtn').onclick = () => {
  if(document.getElementById('pin').value !== cfg.ADMIN_PIN){ alert('Falsche PIN'); return; }
  sessionStorage.setItem('rampenruf_admin','1');
  loginBox.classList.add('hidden'); adminBox.classList.remove('hidden'); start();
};

document.getElementById('refreshBtn').onclick = load;
document.getElementById('showQrBtn').onclick = () => {
  const box = document.getElementById('qrBox');
  box.classList.toggle('hidden');
  const url = cfg.SITE_URL || location.href.replace('admin.html','index.html');
  driverUrl.textContent = url;
  document.getElementById('qrcode').innerHTML='';
  new QRCode(document.getElementById('qrcode'), { text: url, width: 220, height: 220 });
};

rows.addEventListener('click', async e => {
  const id = e.target.dataset.call || e.target.dataset.done;
  if(!id) return;
  if(e.target.dataset.call){
    const ramp = document.querySelector(`input[data-id="${id}"]`).value.trim();
    if(!ramp) return alert('Rampe eintragen, z. B. 60');
    await updateDriver(id, { ramp, status: 'gerufen', called_at: new Date().toISOString() });
  } else {
    await updateDriver(id, { status: 'erledigt', finished_at: new Date().toISOString() });
  }
});

function start(){
  load();
  channel = db.channel('drivers-changes').on('postgres_changes', { event: '*', schema: 'public', table: 'drivers' }, load).subscribe();
}
if(sessionStorage.getItem('rampenruf_admin')==='1'){
  loginBox.classList.add('hidden'); adminBox.classList.remove('hidden'); start();
}
